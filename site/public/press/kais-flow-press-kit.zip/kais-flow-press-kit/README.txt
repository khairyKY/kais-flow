Kai's Flow — press kit

Kai's Flow is a free personal planner that looks and feels like a 19th-century botanical field journal.
It brings tasks, time blocks, habits and a journal into one calm page, and works on the web, Android
and Windows. It's made by one student, Kai, who built it for himself first.

Web: https://kais-flow.kaidagoat.workers.dev
Source and releases: https://github.com/khairyKY/kais-flow

The mark: k-mark-light-1024.png and k-mark-dark-1024.png. Please don't recolour the K or the paper.
Colours: Linen #EFE9DB · Parchment #FBF6E9 · Bark ink #2A2420 · Terra ink #9C5139 · Sage #8A9A7E ·
         Lavender #A8A0BE · Hydrangea #9AB4BE · Blossom #D4A8B0
Type: Source Serif 4 (headings and the page) · Inter Tight (interface) · Courier Prime (captions and
      times) · Caveat (notes in the margin) — all free on Google Fonts.
Screenshots: screenshots/*.png, drawn from the app's own screens with sample data.
